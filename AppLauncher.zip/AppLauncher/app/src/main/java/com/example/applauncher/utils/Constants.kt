package com.example.applauncher.utils

const val BLOCKED_API_FAILED_ERROR = "Failed to get blocked apps"